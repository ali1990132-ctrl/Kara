require("dotenv").config();
const express = require("express");

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static("public"));

const PORT = Number(process.env.PORT || 3000);
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || "";
const WA_TOKEN = process.env.WHATSAPP_TOKEN || "";
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID || "";
const GRAPH_VERSION = process.env.GRAPH_API_VERSION || "v23.0";
const ADMIN_PHONE = (process.env.ADMIN_PHONE || "").replace(/\D/g, "");

const plans = {
  youth: {
    label: "الشبابي",
    durations: [
      { key: "1m", label: "شهر واحد", price: 10000 },
      { key: "3m", label: "3 أشهر", price: 25000 },
      { key: "6m", label: "6 أشهر", price: 40000 },
      { key: "12m", label: "سنة", price: 60000 }
    ]
  },
  family: {
    label: "العائلي",
    durations: [
      { key: "1m", label: "شهر واحد", price: 5000 },
      { key: "3m", label: "3 أشهر", price: 10000 },
      { key: "6m", label: "6 أشهر", price: 15000 },
      { key: "12m", label: "سنة", price: 25000 }
    ]
  }
};

const paymentMethods = {
  master: { label: "ماستر الرافدين", details: "9769867020" },
  zain: { label: "زين كاش", details: "07711608207" },
  asia: { label: "رصيد آسيا", details: "07711608207" }
};

// In-memory state is for testing only. A production deployment should use a persistent database.
const sessions = new Map();

function money(n) {
  return `${Number(n).toLocaleString("en-US")} د.ع`;
}
function getSession(from) {
  if (!sessions.has(from)) sessions.set(from, {});
  return sessions.get(from);
}
function clearSession(from) {
  sessions.set(from, {});
}
function apiReady() {
  return Boolean(WA_TOKEN && PHONE_NUMBER_ID);
}
async function graphPost(path, body) {
  if (!apiReady()) throw new Error("WhatsApp API credentials are not configured.");
  const response = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${path}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${WA_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("Meta API error:", response.status, JSON.stringify(data));
    throw new Error(`Meta API request failed (${response.status})`);
  }
  return data;
}
async function sendText(to, body) {
  return graphPost(`${PHONE_NUMBER_ID}/messages`, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to,
    type: "text",
    text: { preview_url: false, body }
  });
}
async function sendButtons(to, body, buttons) {
  return graphPost(`${PHONE_NUMBER_ID}/messages`, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to,
    type: "interactive",
    interactive: {
      type: "button",
      body: { text: body },
      action: {
        buttons: buttons.slice(0, 3).map(b => ({
          type: "reply",
          reply: { id: b.id, title: b.title.slice(0, 20) }
        }))
      }
    }
  });
}
async function sendList(to, body, buttonText, sections) {
  return graphPost(`${PHONE_NUMBER_ID}/messages`, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to,
    type: "interactive",
    interactive: {
      type: "list",
      body: { text: body },
      action: { button: buttonText.slice(0, 20), sections }
    }
  });
}
async function sendMainMenu(to) {
  clearSession(to);
  await sendButtons(to,
    "أهلاً بيك في كارة ستور 👑\nاختار شنو تحتاج من القائمة:",
    [
      { id: "START_ORDER", title: "طلب اشتراك" },
      { id: "PRICES", title: "الأسعار" },
      { id: "SUPPORT", title: "الدعم الفني" }
    ]);
}
async function showPlanMenu(to) {
  await sendButtons(to, "اختار نوع الاشتراك:", [
    { id: "PLAN_YOUTH", title: "الشبابي" },
    { id: "PLAN_FAMILY", title: "العائلي" },
    { id: "BACK_HOME", title: "رجوع" }
  ]);
}
async function showDurationMenu(to, planKey) {
  const plan = plans[planKey];
  const rows = plan.durations.map(d => ({
    id: `DUR_${planKey}_${d.key}`,
    title: `${d.label} — ${money(d.price)}`,
    description: "اختيار مدة الاشتراك"
  }));
  await sendList(to, `اختار مدة اشتراك ${plan.label}:`, "عرض المدد", [
    { title: "المدد والأسعار", rows }
  ]);
}
async function showPaymentMenu(to) {
  await sendButtons(to, "اختار طريقة الدفع:", [
    { id: "PAY_MASTER", title: "ماستر الرافدين" },
    { id: "PAY_ZAIN", title: "زين كاش" },
    { id: "PAY_ASIA", title: "رصيد آسيا" }
  ]);
}
async function showPrices(to) {
  const text = [
    "👑 أسعار كارة ستور",
    "",
    "الشبابي:",
    "• شهر: 10,000 د.ع",
    "• 3 أشهر: 25,000 د.ع",
    "• 6 أشهر: 40,000 د.ع",
    "• سنة: 60,000 د.ع",
    "",
    "العائلي:",
    "• شهر: 5,000 د.ع",
    "• 3 أشهر: 10,000 د.ع",
    "• 6 أشهر: 15,000 د.ع",
    "• سنة: 25,000 د.ع",
    "",
    "للطلب، اكتب (اشتراك) أو اضغط طلب اشتراك."
  ].join("\n");
  await sendText(to, text);
}
async function notifyAdmin(message) {
  if (!ADMIN_PHONE) {
    console.log("ADMIN_PHONE not configured; admin notification skipped:", message);
    return;
  }
  await sendText(ADMIN_PHONE, message);
}
async function handleIncomingMessage(from, msg) {
  const session = getSession(from);
  const text = (msg.text?.body || "").trim();
  const interactiveId = msg.interactive?.button_reply?.id || msg.interactive?.list_reply?.id || "";
  const input = interactiveId || text;
  const lower = text.toLowerCase();

  if (msg.type === "image" || msg.type === "document") {
    const order = session.order;
    if (!order) {
      await sendText(from, "وصلتنا مرفقاتك. حتى نكمل طلب التفعيل، ابدأ من (طلب اشتراك) وحدد الباقة وطريقة الدفع أولاً.");
      return;
    }
    const mediaId = msg.image?.id || msg.document?.id || "غير متاح";
    const caption = msg.image?.caption || msg.document?.caption || "";
    await sendText(from, "استلمنا الوصل مبدئياً ✅\nراح نراجع التحويل يدوياً. لا ترسل معلومات البطاقة السرية أو رمز OTP.");
    await notifyAdmin(
      `طلب تفعيل جديد - كارة ستور\nالزبون: ${from}\nالباقة: ${order.planLabel}\nالمدة: ${order.durationLabel}\nالسعر: ${money(order.price)}\nالدفع: ${order.paymentLabel}\nمعرّف صورة الوصل (Media ID): ${mediaId}\nملاحظة الوصل: ${caption || "لا توجد"}\nراجع التحويل يدوياً قبل التفعيل.`
    );
    return;
  }

  if (input === "START_ORDER" || lower === "طلب اشتراك" || lower === "اشتراك") {
    await showPlanMenu(from);
    return;
  }
  if (["hi", "hello", "start", "القائمة", "مرحبا", "السلام عليكم", "menu"].includes(lower)) {
    await sendMainMenu(from);
    return;
  }
  if (input === "PRICES" || lower === "الأسعار") {
    await showPrices(from); return;
  }
  if (input === "SUPPORT" || lower === "الدعم") {
    await sendText(from, "للدعم الفني، اكتب مشكلتك برسالة واضحة، وراح يتابعها فريق كارة ستور. لا ترسل كلمات مرور أو رموز تحقق.");
    return;
  }
  if (input === "BACK_HOME") { await sendMainMenu(from); return; }
  if (input === "PLAN_YOUTH") {
    session.order = { planKey: "youth", planLabel: plans.youth.label };
    await showDurationMenu(from, "youth"); return;
  }
  if (input === "PLAN_FAMILY") {
    session.order = { planKey: "family", planLabel: plans.family.label };
    await showDurationMenu(from, "family"); return;
  }
  const durationMatch = input.match(/^DUR_(youth|family)_(1m|3m|6m|12m)$/);
  if (durationMatch) {
    const [, planKey, durationKey] = durationMatch;
    const duration = plans[planKey].durations.find(d => d.key === durationKey);
    session.order = {
      ...(session.order || {}),
      planKey, planLabel: plans[planKey].label,
      durationKey, durationLabel: duration.label, price: duration.price
    };
    await sendText(from, `تفاصيل طلبك 👑\nالباقة: ${session.order.planLabel}\nالمدة: ${duration.label}\nالسعر: ${money(duration.price)}\n\nاختار طريقة الدفع من الرسالة التالية.`);
    await showPaymentMenu(from);
    return;
  }
  const paymentMap = {
    PAY_MASTER: "master", PAY_ZAIN: "zain", PAY_ASIA: "asia"
  };
  if (paymentMap[input]) {
    if (!session.order?.price) {
      await sendText(from, "حدد الباقة والمدة أولاً. اكتب (اشتراك) للبدء.");
      return;
    }
    const method = paymentMethods[paymentMap[input]];
    session.order.paymentKey = paymentMap[input];
    session.order.paymentLabel = method.label;
    await sendText(from,
      `طريقة الدفع: ${method.label}\nبيانات الدفع: ${method.details}\nالمبلغ المطلوب: ${money(session.order.price)}\n\nبعد التحويل، أرسل صورة واضحة للوصل هنا. سيتم مراجعة التحويل يدوياً قبل التفعيل.\n\nتنبيه: لا ترسل رقم البطاقة الكامل أو PIN أو رمز OTP.`);
    await notifyAdmin(`بدأ طلب اشتراك - كارة ستور\nالزبون: ${from}\nالباقة: ${session.order.planLabel}\nالمدة: ${session.order.durationLabel}\nالسعر: ${money(session.order.price)}\nالدفع: ${method.label}`);
    return;
  }
  if (input === "PRICES" || lower.includes("سعر")) { await showPrices(from); return; }
  await sendButtons(from,
    "ما فهمت طلبك تماماً. اختار أحد الخيارات:",
    [
      { id: "START_ORDER", title: "طلب اشتراك" },
      { id: "PRICES", title: "الأسعار" },
      { id: "SUPPORT", title: "الدعم الفني" }
    ]);
}

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    service: "Kara Store WhatsApp bot",
    apiConfigured: apiReady(),
    adminNotificationConfigured: Boolean(ADMIN_PHONE),
    note: "Testing starter. Use a persistent database before production."
  });
});

// Meta webhook verification
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && VERIFY_TOKEN && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Receive WhatsApp events. Return 200 quickly to acknowledge Meta.
app.post("/webhook", (req, res) => {
  res.sendStatus(200);
  const body = req.body;
  if (body.object !== "whatsapp_business_account") return;
  for (const entry of body.entry || []) {
    for (const change of entry.changes || []) {
      const value = change.value || {};
      for (const msg of value.messages || []) {
        const from = msg.from;
        if (!from) continue;
        handleIncomingMessage(from, msg).catch(err => {
          console.error("Message handling failed:", err.message);
          sendText(from, "عذراً، صار خلل مؤقت. حاول بعد قليل أو تواصل مع الدعم.").catch(() => {});
        });
      }
    }
  }
});

app.listen(PORT, () => {
  console.log(`Kara Store bot listening on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
  if (!VERIFY_TOKEN) console.warn("Set VERIFY_TOKEN in .env before webhook setup.");
  if (!apiReady()) console.warn("Set WHATSAPP_TOKEN and PHONE_NUMBER_ID in .env.");
});
